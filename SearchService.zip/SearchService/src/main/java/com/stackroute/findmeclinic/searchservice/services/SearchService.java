package com.stackroute.findmeclinic.searchservice.services;

import java.util.List;

import com.stackroute.findmeclinic.searchservice.model.Doctor;

public interface SearchService {
	
	public List<Doctor> getDoctorByName(String name);

}
